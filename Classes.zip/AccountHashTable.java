package com.banking.datastructures;

import com.banking.models.Account;
import java.util.List;
import java.util.ArrayList;
import java.io.*;

public class AccountHashTable {
    // Global static instance taake Login se direct AccountHashTable.search(accNum) call ho sakay
    private static AccountHashTable globalInstance = new AccountHashTable(100);
    private static final String DATA_FILE = "bank_accounts.dat"; // Data save karne ke liye file name

    static {
        // Jaise hi application start hogi, ye file se purana data khud load kar lega!
        globalInstance.loadFromFile(DATA_FILE);
    }

    public static AccountHashTable getInstance() {
        return globalInstance;
    }

    // Static search method jo login ke liye use hoga (Username se search karega)
    public static Account search(String username) {
        return globalInstance.get(username);
    }

    // --- FILE HANDLING METHODS ---

    // 1. Saare accounts ko file mein save karne ke liye
    public void saveToFile(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(this.getAllAccounts());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 2. File se purane accounts dobara load karne ke liye (Username ko key banakar)
    @SuppressWarnings("unchecked")
    public void loadFromFile(String filename) {
        File file = new File(filename);
        if (!file.exists()) return; // Agar file mojood nahi toh skip kar dein
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            List<Account> list = (List<Account>) ois.readObject();
            for (Account acc : list) {
                // Account ke apne username ko key banakar table mein rakhein
                String loginKey = (acc.getUsername() != null && !acc.getUsername().isEmpty()) ? acc.getUsername() : acc.getAccountId();
                int bucketIndex = hash(loginKey);
                HashNode newNode = new HashNode(loginKey, acc);
                newNode.next = table[bucketIndex];
                table[bucketIndex] = newNode;
                size++;
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Internal Node class for Separate Chaining collision handling
    private static class HashNode implements Serializable {
        private static final long serialVersionUID = 1L;
        String key;     // Username / Account Identifier
        Account value;  // Account Object
        HashNode next;

        public HashNode(String key, Account value) {
            this.key = key;
            this.value = value;
            this.next = null;
        }
    }

    private HashNode[] table;
    private int capacity;
    private int size;

    // Constructor with default capacity
    public AccountHashTable(int capacity) {
        this.capacity = capacity;
        this.table = new HashNode[capacity];
        this.size = 0;
    }

    // Custom Hash Function for String Keys
    private int hash(String key) {
        int hashVal = 0;
        for (int i = 0; i < key.length(); i++) {
            hashVal = 31 * hashVal + key.charAt(i);
        }
        hashVal = hashVal % capacity;
        if (hashVal < 0) {
            hashVal += capacity;
        }
        return hashVal;
    }

    // Insert or update an account using Username as key - O(1) average time
    public void put(String key, Account account) {
        // Yeh ensure karega ke key hamesha username ho (agar available ho)
        String actualKey = (account.getUsername() != null && !account.getUsername().isEmpty()) ? account.getUsername() : key;
        
        int bucketIndex = hash(actualKey);
        HashNode head = table[bucketIndex];

        // Check if key already exists, update value if found
        HashNode current = head;
        while (current != null) {
            if (current.key.equals(actualKey)) {
                current.value = account;
                saveToFile(DATA_FILE); // Data update hote hi file mein save ho jaye ga
                return;
            }
            current = current.next;
        }

        // Insert new node at the head of the chain using username as key
        HashNode newNode = new HashNode(actualKey, account);
        newNode.next = head;
        table[bucketIndex] = newNode;
        size++;
        
        saveToFile(DATA_FILE); // Naya account add hote hi file mein save ho jaye ga!
    }

    // Retrieve account by Username - O(1) average time (Instance method)
    public Account get(String key) {
        int bucketIndex = hash(key);
        HashNode current = table[bucketIndex];

        while (current != null) {
            if (current.key.equals(key)) {
                return current.value;
            }
            current = current.next;
        }
        return null; // Account not found
    }

    // Saare accounts ko aik List mein nikalne ke liye method
    public List<Account> getAllAccounts() {
        List<Account> accountList = new ArrayList<>();
        if (table == null) return accountList;
        
        for (int i = 0; i < table.length; i++) {
            HashNode current = table[i];
            while (current != null) {
                accountList.add(current.value);
                current = current.next;
            }
        }
        return accountList;
    }

    // Remove account from hash table
    public boolean remove(String key) {
        int bucketIndex = hash(key);
        HashNode head = table[bucketIndex];
        HashNode prev = null;
        HashNode current = head;

        while (current != null) {
            if (current.key.equals(key)) {
                if (prev == null) {
                    table[bucketIndex] = current.next;
                } else {
                    prev.next = current.next;
                }
                size--;
                saveToFile(DATA_FILE); // Account delete hone par bhi file update ho jaye gi
                return true;
            }
            prev = current;
            current = current.next;
        }
        return false;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }
}